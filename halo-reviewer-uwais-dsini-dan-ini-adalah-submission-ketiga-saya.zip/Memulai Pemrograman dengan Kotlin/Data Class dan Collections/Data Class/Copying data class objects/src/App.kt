data class DataUser(val name : String, val age : Int) {

    fun intro() {
        println("My name is $name and i'm $age years old")
    }
}
fun main(){
    val dataUser=
}