/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah struktur kode yang sudah ada. Kecuali:
 *    - Untuk melakukan improvisasi kode
 *    - Mengikuti perintah yang ada
 *
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */

fun main() {
    val valueA = 101
    val valueB = 52
    val valueC = 99

    // TODO 2
    val resultA = calculateResult(valueA, valueB, valueC)
    val resultB = calculateResult(valueA, valueB, null )

    println("""
        ResultA is $resultA
        ResultB is $resultB
    """.trimIndent())
}

/** result A : 54 = {52 + (50 - 52 = 2)}
 *  result B : 103 = {101 + (50 - 52 = 2)}
 **/

fun calculateResult(valueA: Int, valueB: Int, valueC: Int?): Int {
    // TODO 1
    val result = valueA + (valueB - (valueC?: 50))
    return result
}



