// main function
fun main() {
    val name = "Unicode test: \u1F605"
    print(name)
}